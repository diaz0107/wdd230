function allMyFunctions(){
    lastUpdated(); 
    year(); 
} 
    