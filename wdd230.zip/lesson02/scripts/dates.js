document.getElementById("year").innerHTML = new Date().getFullYear()
document.getElementById("lst-updt").innerHTML = "Last updated: "+document.lastModified